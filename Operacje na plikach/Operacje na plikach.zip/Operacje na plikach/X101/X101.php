<?php
$file=touch('nazwisko_i_imie.txt');
$file=fopen("doSkasowania.txt", "w");
$file=unlink('doSkasowania.txt');
$file=mkdir('Czuchran');
$file=touch('C:\xampp\htdocs\3pir\Operacje na plikach\X101\Czuchran\nazwisko_i_imie.txt');
//Eryk Czuchran